package com.example.mobile04;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {
    Button b1, b2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        b1 = findViewById(R.id.b1);
        b2 = findViewById(R.id.b2);

        b1.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {
                Log.d("","버튼1을 클릭했음.");
                AlertDialog.Builder dlg = new AlertDialog.Builder(MainActivity.this);
                dlg.setTitle("제목");
                dlg.setIcon(R.mipmap.ic_launcher_round);
                //dlg.setMessage("버튼을 눌렀기때문에 내가 떴어요!!!");
                String[] versionArray = new String[] {"오레오", "파이", "큐(Q)"};

                dlg.setItems(versionArray, new DialogInterface.OnClickListener() {

                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        Log.d("","선택한 인덱스는 " + i);
                        String data = versionArray[i];
                        String site = "https://dict.naver.com/search.nhn?dicQuery=%EC%98%A4%EB%A0%88%EC%98%A4&query=%EC%98%A4%EB%A0%88%EC%98%A4&target=dic&query_utf=&isOnlyViewEE=" + data;
                        Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(site));
                        startActivity(intent);

                     }// on
                }); // setItems

                dlg.setPositiveButton("확인버튼" ,null);
                dlg.show();

            } //on
        }); // b1

        b2.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {
                Log.d("","버튼2를 클릭했음.");
                AlertDialog.Builder dlg = new AlertDialog.Builder(MainActivity.this);
                dlg.setTitle("사이트");
                dlg.setIcon(R.mipmap.ic_launcher_round);
                // dlg.setMessage("버튼2 눌렀기때문에 내가 떴어요!!!");
                String[] versionArray = new String[] {"다음웹툰", "왓챠", "넷플릭스"};

                dlg.setItems(versionArray, new DialogInterface.OnClickListener() {

                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        Log.d("","선택한 인덱스는 " + i + " >> " + versionArray[i]);
                        String pre = "http://www.";
                        String post = ".com";
                        if (versionArray[i].equals("다음웹툰")) {
                            post = ".net";
                        }
                        String site = pre + versionArray[i] + post;

                        Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(site));
                        startActivity(intent);

                    }// on
                }); // setItems

                dlg.setPositiveButton("확인버튼" ,null);
                dlg.show();

            } //on
        }); // b2

    } //onCreate
} // class