package com.example.mobile04;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity2 extends AppCompatActivity {

    Button b3, b4, b5;
    EditText t1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        t1 = findViewById(R.id.t1);

        b3 = findViewById(R.id.b3);
        b5 = findViewById(R.id.b5);

        b3.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {

                String t1val = t1.getText().toString();
                String url = "https://www." + t1val + ".com";
                Intent intent = new Intent(Intent.ACTION_VIEW,
                        Uri.parse(url));
                startActivity(intent);

            }
        });

        b4 = findViewById(R.id.b4);
        b4.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {

                AlertDialog.Builder dlg = new AlertDialog.Builder(MainActivity2.this);
                dlg.setTitle("신촌 맛집");
                String[] list = new String[] { "정육면체", "여우골", "신촌부대찌개" };

                dlg.setItems(list, new DialogInterface.OnClickListener() {

                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        Log.d("","선택한 인덱스는 " + i);
                        String data = list[i];
                        String url = "https://search.naver.com/search.naver?where=nexearch&sm=top_hty&fbm=1&ie=utf8&query=" + data;
                        Intent intent = new Intent(Intent.ACTION_VIEW,
                                Uri.parse(url));
                        startActivity(intent);

                    }// on
                }); // setItems

                dlg.setPositiveButton("확인" ,null);
                dlg.show();

            }
        });

        b5.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {

                Intent intent = new Intent(MainActivity2.this, MainActivity.class);
                startActivity(intent);

            }
        });

    }
}