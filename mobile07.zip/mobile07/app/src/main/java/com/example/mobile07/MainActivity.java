package com.example.mobile07;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity implements View. OnClickListener{

    Button go, reset;
    EditText tourName;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        go = findViewById(R.id.go);
        tourName = findViewById(R.id.tourName);
        reset = findViewById(R.id.reset);

        go.setOnClickListener(this);
        reset.setOnClickListener(this);

    }
            @Override
            public void onClick(View view) {
                String who = "";

                if (view.getId() == R.id.go) { // 버튼 구분
                    who = "go";
                } else {
                    who = "reset";
                } // else

                String data = tourName.getText().toString();
                Intent intent = new Intent(MainActivity.this,
                        MainActivity2.class);

                intent.putExtra("tourName", data);
                intent.putExtra("who", who);
                startActivity(intent);

            } // onClick()
}