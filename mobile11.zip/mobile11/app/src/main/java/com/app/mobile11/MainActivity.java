package com.app.mobile11;

import androidx.appcompat.app.AppCompatActivity;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    EditText edtName, edtNumber;
    ListView edtNameResult, edtNumberResult;
    Button button, button2, button3, button4, button5;
    MyDBHelper myDBHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        edtName = findViewById(R.id.edtName);
        edtNumber = findViewById(R.id.edtNumber);
        edtNameResult = findViewById(R.id.edtNameResult);
        edtNumberResult = findViewById(R.id.edtNumberResult);

        button = findViewById(R.id.button);
        button2 = findViewById(R.id.button2);
        button3 = findViewById(R.id.button3);
        button4 = findViewById(R.id.button4);
        button5 = findViewById(R.id.button5);

        myDBHelper = new MyDBHelper(this);

        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                SQLiteDatabase sqlDB = myDBHelper.getWritableDatabase(); // 스트링을 가져오라는 디비
                myDBHelper.onUpgrade(sqlDB, 1, 2);
                Log.d("sqlite3DDL","DDL 호출함----");
                sqlDB.close();
            }
        });

        button2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                SQLiteDatabase sqlDB = myDBHelper.getWritableDatabase();
                String name = edtName.getText().toString();
                String number = edtNumber.getText().toString();
                sqlDB.execSQL("INSERT INTO groupTBL2 VALUES ('" + name + "', '" + number + "')");
                Log.d("sqlite3DML","데이터 삽입 성공----");

                sqlDB.close();
                Log.d("sqlite3DML","데이터베이스 closed----");
            }
        });

        button3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                SQLiteDatabase sqlDB = myDBHelper.getWritableDatabase();
                //String name = edtName.getText().toString();
                //"SELECT * FROM groupTBL2 where gname = '"+ name +"';"
                String sql = "SELECT * FROM groupTBL2";
                Cursor cursor = sqlDB.rawQuery(sql, null);

                String result2 = "";
                ArrayList<String> nameList = new ArrayList<>();
                ArrayList<Integer> numberList = new ArrayList<>();
//                String strNames = "그룹이름" + "\r\n";
//                String strNumber = "인원" + "\r\n";
                while (cursor.moveToNext()) {
                    // cursor.moveToNext() 첫번째 행을 가르키면서 있는지 없는지 체크
                    // 있으면 true리턴
                    // 각 열에 있는 값들을 인덱스로 꺼내오면 됨
                    // 인덱스는 0부터 시작
                    //String result = cursor.getString(0) + ": " + cursor.getString(1);
                    //Log.d("sqlite3DML",result2);
                    //result2 += result + " ";
                    nameList.add(cursor.getString(0));
                    numberList.add(cursor.getInt(1));
//                    strNames += cursor.getString(0) + "\r\n";
//                    strNumber += cursor.getString(1) + "\r\n";
                }
//                edtNameResult.setText(strNames);
//                edtNumberResult.setText(strNumber);

                cursor.close();
                sqlDB.close();

                ArrayAdapter<String> nameAdapter = new ArrayAdapter<String>(getApplicationContext(), android.R.layout.simple_list_item_1, nameList);
                ArrayAdapter<Integer> numberAdapter = new ArrayAdapter<Integer>(getApplicationContext(), android.R.layout.simple_list_item_1, numberList);
                edtNameResult.setAdapter(nameAdapter);
                edtNumberResult.setAdapter(numberAdapter);
            }
        });

        button4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                SQLiteDatabase sqlDB = myDBHelper.getWritableDatabase();
                String name = edtName.getText().toString();
                String number = edtNumber.getText().toString();
                sqlDB.execSQL("update groupTBL2 set gNumber = '" + number + "' where gName = '" + name + "';");
                Log.d("sqlite3DML","데이터 수정 성공----");

            }
        });

        button5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                SQLiteDatabase sqlDB = myDBHelper.getWritableDatabase();
                String name = edtName.getText().toString();
                sqlDB.execSQL("delete from groupTBL2 where gName = " + name + ";");
                Log.d("sqlite3DML","데이터 삭제 성공----");

                sqlDB.close();
                Log.d("sqlite3DML","데이터베이스 closed----");
            }
        });
    }
}