package com.example.mobile03;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class page1 extends AppCompatActivity {
    Button button24, button25, button26;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_page1);
        button24 = findViewById(R.id.button24);
        button25 = findViewById(R.id.button25);
        button26 = findViewById(R.id.button26);

        button24.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(getApplicationContext(),
                        "page2로 이동", Toast.LENGTH_SHORT).show();
                // 화면 넘겨주는 객체생성
                // 생성자(현제액티비티, 넘어갈 액티비티)
                Intent intent = new Intent(page1.this, page2.class);
                startActivity(intent);
            }
        });

        button25.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(getApplicationContext(),
                        "page2로 이동",
                        Toast.LENGTH_SHORT).show();
                // 화면 넘겨주는 객체생성
                // 생성자(현제액티비티, 넘어갈 액티비티)
                Intent intent = new Intent(page1.this, page3.class);
                startActivity(intent);
            }
        });

        button26.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(getApplicationContext(),
                        "page1 종료",
                        Toast.LENGTH_SHORT).show();
                finish();
            }
        });
    }
}