package com.example.mobile03;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class page2 extends AppCompatActivity {
    Button button27, button28, button29;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_page2);

        button27 = findViewById(R.id.button27);
        button28 = findViewById(R.id.button28);
        button29 = findViewById(R.id.button29);

        button27.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(getApplicationContext(),
                        "page1로 이동", Toast.LENGTH_SHORT).show();
                // 화면 넘겨주는 객체생성
                // 생성자(현제액티비티, 넘어갈 액티비티)
                Intent intent = new Intent(page2.this, page1.class);
                startActivity(intent);
            }
        });

        button28.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(getApplicationContext(),
                        "page3로 이동", Toast.LENGTH_SHORT).show();
                // 화면 넘겨주는 객체생성
                // 생성자(현제액티비티, 넘어갈 액티비티)
                Intent intent = new Intent(page2.this, page3.class);
                startActivity(intent);
            }
        });


        button29.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(getApplicationContext(),
                        "page2 종료",
                        Toast.LENGTH_SHORT).show();
                finish();
            }
        });
    }
}