package com.example.mobile02;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity2 extends AppCompatActivity {

    TextView text3, text6;
    Button b3;
    EditText text4, text5;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        text3 = findViewById(R.id.text3);
        text4 = findViewById(R.id.text4);
        text5 = findViewById(R.id.text5);
        text6 = findViewById(R.id.text6);
        b3 = findViewById(R.id.b3);

        b3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //클릭했을 때 처리하고 싶은 내용을 여기에다가 쓰면 됨.
                Log.i("", "-------> b3을 클릭했음.");
                String data1 = text4.getText().toString(); //입력한 값!!
                String data2 = text5.getText().toString(); //입력한 값!!
                int data3 = Integer.parseInt(data1);
                int data4 = Integer.parseInt(data2);
                int data5 = data3+data4;
                String data = Integer.toString(data5);

                text6.setText("결과는" + data);
            }
        }); //b1
    }
}