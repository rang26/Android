package com.mega.mobile06;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity5 extends AppCompatActivity {

    EditText text51, text52;
    TextView v51,v52, v53;
    Button b51;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main5);

        text51 = findViewById(R.id.text51);
        text52 = findViewById(R.id.text52);
        b51 = findViewById(R.id.b51);
        v53 = findViewById(R.id.v53);

        b51.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String id = text51.getText().toString();
                String pw = text52.getText().toString();

                if (id.equals("root") && pw.equals("1234")){

                    Intent intent = new Intent(MainActivity5.this , MainActivity4.class);
                    Toast.makeText(getApplicationContext(),
                    "로그인 성공!",
                    Toast.LENGTH_SHORT
                    ).show();
                    startActivity(intent);
                } else {
                    Toast.makeText(getApplicationContext(),
                            "로그인 실패",
                            Toast.LENGTH_SHORT
                    ).show();
                }

            }
        });


    }
}