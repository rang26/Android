package com.mega.mobile06;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

public class MainActivity4 extends AppCompatActivity {

    EditText text41, text42;
    TextView v41,v42;
    Button b41,b42;
    ImageView i41;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main4);

        text41 = findViewById(R.id.text41);
        text42 = findViewById(R.id.text42);
        b41 = findViewById(R.id.b41);
        b42 = findViewById(R.id.b42);

        b41.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String title = text41.getText().toString();
                String content = text42.getText().toString();

                Toast.makeText(getApplicationContext(),
                        "게시물 작성 완료",
                        Toast.LENGTH_SHORT
                ).show();

                FileOutputStream file = null;
                try {
                    file = openFileOutput(title + ".txt", MODE_PRIVATE);
                    file.write(content.getBytes());
                    file.close();

                } catch (FileNotFoundException e) {
                    e.printStackTrace();
                    Log.d("","파일이 존재하지 않습니다.");
                } catch (IOException e) {
                    e.printStackTrace();
                    Log.d("","파일을 읽고 쓰는 도중 에러가 발생했습니다.");
                }catch (Exception e){
                    e.printStackTrace();
                    Log.d("", "에러가 발생했습니다.");
                }

            }
        });
    }
}