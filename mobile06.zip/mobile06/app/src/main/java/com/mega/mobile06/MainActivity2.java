package com.mega.mobile06;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.widget.Toast;

import java.util.ArrayList;

public class MainActivity2 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        Intent intent = getIntent();
        String name = intent.getStringExtra("name"); // String 값받 기
        String list = ""; //리스트 값 받기
        int age = intent.getIntExtra("age", 0); //int 값 받기
        double height = intent.getDoubleExtra("height", 0); //double 값 받기
        String[] hobby = intent.getStringArrayExtra("hobby"); // 배열 받기
        ArrayList<String> subject = intent.getStringArrayListExtra("subject");
        Log.d("확인", subject.toString());
        for (String one : hobby){
            list += one + " ";
        }
        Toast.makeText(getApplicationContext(),
                "받은 이름은 >>" + name + ", \nhobby >>" + list + "\nsubject >>" + subject,
                Toast.LENGTH_SHORT
                ).show();
        Toast.makeText(getApplicationContext(),
                "받은 이름은 >>" + name + "\nheight >>" + height,
                Toast.LENGTH_SHORT
                ).show();

    } // onCreate
} // class