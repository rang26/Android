package com.mega.mobile06;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity { // 기본적으로 상속이 구현되어 있다.

    Button b1; // 버튼을 가지고 오자!




    @Override // 오버라이드
    protected void onCreate(Bundle savedInstanceState) { // onCreate가 화면을 만드는 가장 기본적인 메서드
        super.onCreate(savedInstanceState); // super 이부분이 없으면 부모 메서드가 실행되지 않는다.
        // 부모 클레스의 메서드를 호출할때 사용
        // 액티비티의 기본 틀 설정, 제목 넣고, 기본색 설정
        setContentView(R.layout.activity_main); // 윗 부분 실행 후 순차적으로 실행된다.

        b1 = findViewById(R.id.b1); // id를 값으로 버튼을 가져왔다

        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //액티비티를 넘기려고 한다.
                //넘길때 데이터를 함께 보내려고 한다.

                Intent intent = new Intent(MainActivity.this,MainActivity2.class); // 왼쪽은 현재의 주소, 오른쪽은 넘길쪽의 주소
                intent.putExtra("name","honggildong"); // String 값 주기 (왼쪽 이름, 오른쪽 값)
                intent.putExtra("age",33); // int 값 주기
                intent.putExtra("height",173.9); // double 값 주기
                String [] hobby = {"놀기", "자기" , "또놀기"}; //  배열 값 주기
                ArrayList<String> subject = new ArrayList<>(); // 어레이리스트 값 주기
                subject.add("컴퓨터");
                subject.add("영어");
                subject.add("수학");
                subject.add("스포츠");
                intent.putExtra("hobby", hobby);
                intent.putExtra("subject", subject);
                startActivity(intent);
            }
        });




    } //onCreate
} //class